package Com.TSL.UtilitiesForTheWeatherApp.UtilitiesForAnInputManager;


public enum AnExitStatus
{

    SUCCESS
    
}
